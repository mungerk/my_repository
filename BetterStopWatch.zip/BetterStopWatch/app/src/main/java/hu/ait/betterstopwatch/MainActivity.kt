package hu.ait.betterstopwatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.times.view.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart.setOnClickListener {
            chronometer.start()

        }
        btnMark.setOnClickListener{
            chronometer.stop()
            var time = chronometer.format
            addTime(time)
        }

        btnReset.setOnClickListener{
            chronometer.base = SystemClock.elapsedRealtime()
        }
    }


    private fun addTime(time:String){

         var times = layoutInflater.inflate(
            R.layout.times, null, false)

        times.textView.text = time

        layoutContent.addView(times, 0)


    }
}
